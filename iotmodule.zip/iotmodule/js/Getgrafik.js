function fetchData() {
    $.ajax({
        url: 'backend/aksigrafik.php', // Ganti dengan alamat URL yang sesuai
        method: 'GET',
        dataType: 'json',
        success: function (data) {
            // Memperbarui data grafik
            // myChart.data.labels = data.labels;
            myChart1.data.labels = data.labels;
            myChart2.data.labels = data.labels;
            myChart3.data.labels = data.labels;
            myChart1.data.datasets[0].data = data.values1;
            myChart2.data.datasets[0].data = data.values2;
            myChart3.data.datasets[0].data = data.values3;
            // myChart.data.datasets[0].data = data.values1;
            // myChart.data.datasets[1].data = data.values2;
            // myChart.data.datasets[2].data = data.values3;
            // myChart.update();
            myChart1.update();
            myChart2.update();
            myChart3.update();
        },
        error: function (xhr, status, error) {
            console.error('Error fetching data:', error);
        }
    });
}

// GRAFIK 1
var ctx = document.getElementById("chart-sensor1").getContext("2d");
var myChart1= new Chart(ctx, {
type: "line",
data: {
labels: [],
datasets: [{
label: "Sensor Temperature",
tension: 0,
borderWidth: 0,
pointRadius: 5,
pointBackgroundColor: "rgba(255, 255, 255, .8)",
pointBorderColor: "transparent",
borderColor: "rgba(255, 255, 255, .8)",
borderColor: "rgba(255, 255, 255, .8)",
borderWidth: 4,
backgroundColor: "rgba(255, 255, 255, .8)",
data: [],
maxBarThickness: 6
}, ],
},
options: {
responsive: true,
maintainAspectRatio: false,
plugins: {
legend: {
display: false,
}
},
interaction: {
intersect: false,
mode: 'index',
},
scales: {
y: {
grid: {
drawBorder: false,
display: true,
drawOnChartArea: true,
drawTicks: false,
borderDash: [5, 5],
color: 'rgba(255, 255, 255, .2)'
},
ticks: {
suggestedMin: 0,
suggestedMax: 500,
beginAtZero: true,
padding: 10,
font: {
  size: 14,
  weight: 300,
  family: "Roboto",
  style: 'normal',
  lineHeight: 2
},
color: "#fff"
},
},
x: {
grid: {
drawBorder: false,
display: true,
drawOnChartArea: true,
drawTicks: false,
borderDash: [5, 5],
color: 'rgba(255, 255, 255, .2)'
},
ticks: {
display: true,
color: '#f8f9fa',
padding: 10,
font: {
  size: 14,
  weight: 300,
  family: "Roboto",
  style: 'normal',
  lineHeight: 2
},
}
},
},
},
});

// GRAFIK 2
var ctx2 = document.getElementById("chart-sensor2").getContext("2d");
var myChart2 =new Chart(ctx2, {
type: "line",
data: {
labels: [],
datasets: [{
label: "Sensor Humidity",
tension: 0,
borderWidth: 0,
pointRadius: 5,
pointBackgroundColor: "rgba(255, 255, 255, .8)",
pointBorderColor: "transparent",
borderColor: "rgba(255, 255, 255, .8)",
borderColor: "rgba(255, 255, 255, .8)",
borderWidth: 4,
backgroundColor: "transparent",
fill: true,
data: [],
maxBarThickness: 6

}],
},
options: {
responsive: true,
maintainAspectRatio: false,
plugins: {
legend: {
display: false,
}
},
interaction: {
intersect: false,
mode: 'index',
},
scales: {
y: {
grid: {
drawBorder: false,
display: true,
drawOnChartArea: true,
drawTicks: false,
borderDash: [5, 5],
color: 'rgba(255, 255, 255, .2)'
},
ticks: {
display: true,
color: '#f8f9fa',
padding: 10,
font: {
  size: 14,
  weight: 300,
  family: "Roboto",
  style: 'normal',
  lineHeight: 2
},
}
},
x: {
grid: {
drawBorder: false,
display: false,
drawOnChartArea: false,
drawTicks: false,
borderDash: [5, 5]
},
ticks: {
display: true,
color: '#f8f9fa',
padding: 10,
font: {
  size: 14,
  weight: 300,
  family: "Roboto",
  style: 'normal',
  lineHeight: 2
},
}
},
},
},
});

// GRAFIK 3
var ctx3 = document.getElementById("chart-sensor3").getContext("2d");
var myChart3 =new Chart(ctx3, {
type: "line",
data: {
labels: [],
datasets: [{
label: "Sensor LDR",
tension: 0,
borderWidth: 0,
pointRadius: 5,
pointBackgroundColor: "rgba(255, 255, 255, .8)",
pointBorderColor: "transparent",
borderColor: "rgba(255, 255, 255, .8)",
borderWidth: 4,
backgroundColor: "transparent",
fill: true,
data: [],
maxBarThickness: 6

}],
},
options: {
responsive: true,
maintainAspectRatio: false,
plugins: {
legend: {
display: false,
}
},
interaction: {
intersect: false,
mode: 'index',
},
scales: {
y: {
grid: {
drawBorder: false,
display: true,
drawOnChartArea: true,
drawTicks: false,
borderDash: [5, 5],
color: 'rgba(255, 255, 255, .2)'
},
ticks: {
display: true,
padding: 10,
color: '#f8f9fa',
font: {
  size: 14,
  weight: 300,
  family: "Roboto",
  style: 'normal',
  lineHeight: 2
},
}
},
x: {
grid: {
drawBorder: false,
display: false,
drawOnChartArea: false,
drawTicks: false,
borderDash: [5, 5]
},
ticks: {
display: true,
color: '#f8f9fa',
padding: 10,
font: {
  size: 14,
  weight: 300,
  family: "Roboto",
  style: 'normal',
  lineHeight: 2
},
}
},
},
},
});

// REALTIME SELAMA 5 MILI DETIK
setInterval(fetchData, 500);