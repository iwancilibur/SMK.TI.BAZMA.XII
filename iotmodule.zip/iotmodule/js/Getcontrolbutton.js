function updateSwitchStatus(switchId, newStatus) {
    $.post("backend/get-control.php", { id: switchId, status: newStatus }, function(response) {
        loadSwitches();
    });
}

function loadSwitches() {
    $.get("backend/update-control.php", function(data) {
        var switches = JSON.parse(data);
        var switchesHtml = "";
        switches.forEach(function(switchItem) {
            var btnClass = switchItem.status == 1 ? "btn-success" : "btn-danger";
            var statusText = switchItem.status == 1 ? "ON" : "OFF";
            switchesHtml += `
                <button class="btn ${btnClass} toggle-btn" data-switch-id="${switchItem.id}" data-status="${switchItem.status}">
                    ${switchItem.keterangan}
                    <span class="status-text"><br> ${statusText}</span>
                </button>
            `;
        });
        $("#switches").html(switchesHtml);
        
        $(".toggle-btn").click(function() {
            var switchId = $(this).data("switch-id");
            var currentStatus = $(this).data("status");
            updateSwitchStatus(switchId, 1 - currentStatus);
        });
    });
}

$(document).ready(function() {
    loadSwitches();
    setInterval(loadSwitches, 2000); // Poll every 3 seconds
});