function fetchData() {
    // Fetch data from PHP
    fetch('backend/aksiGauge.php')
        .then(response => response.json())
        .then(data => {
            // Update gauge value with fetched data
            gauge1.value = data.values1;
            gauge2.value = data.values2;
            gauge3.value = data.values3;
            gauge1.update();
            gauge2.update();
            gauge3.update();
        })
        .catch(error => console.error('Error fetching data:', error));
}

    var gauge1 = new RadialGauge({
        // ... (your existing gauge configuration)
        renderTo: 'gauge-temperature',
        width: 300,
        height: 300,
        units: "Celcius",
        title: "Temperature",

        startAngle: 40,
        ticksAngle: 280,
        colorPlate: "#ffffff",
        //colorPlateEnd: "#ffffff",
        colorUnits: "#3CA7DB",
        colorNumbers: "#534638",
        colorNeedle: "#8E7860",
        colorNeedleEnd: "#8E7860",
        colorNeedleCircleOuter: "#8E7860",
        colorNeedleCircleOuterEnd: "#8E7860",

        colorNeedleShadowUp: "#8E7860",
        colorNeedleShadowDown: "#8E7860",

        colorMajorTicks: ["#EBEBEB", "#EBEBEB", "#EBEBEB", "#EBEBEB", "#EBEBEB", "#EBEBEB"],
        colorMinorTicks: "#EBEBEB",

        minValue: 0,
        maxValue: 100,
        // maxValue: 200,
        majorTicks: ["0","20","40","60","80","100"],
        // majorTicks: ["0","20","40","60","80","100","120","140","160","180","200"],
        minorTicks: "2",
        strokeTicks: true,
        highlights: [
            {
                "from": -0.25,
                "to": 39.99,
                "color": "#30E3DF"
            },
            {
                "from": 39.99,
                "to": 65.99,
                "color": "#FCE22A"
            },
            {
                "from": 65.99,
                "to": 100.25,
                "color": "#F94A29"
            }
        ],
        //
        highlightsWidth: 25,
        numbersMargin: 12,
        //
        //barWidth: 20,
        //barStrokeWidth: 0,
        //barProgress: 1,
        //barShadow: 0,
        //
        animation: true,
        //animationDuration: 500,
        animationRule: "linear",
        animatedValue: true,
        //animateOnInit: true,

        borders: true,
        valueBox: true,

        needleType: "arrow",
        needleEnd: 65,
        needleWidth: 4,
        needleCircleSize: 10,
        needleCircleInner: true,
        needleCircleOuter: true,
        needleShadow: true,

        borderShadowWidth: 4
    }).draw();


    var gauge2 = new RadialGauge({
        // ... (your existing gauge configuration)
        renderTo: 'gauge-humidity',
        width: 300,
        height: 300,
        units: "%",
        title: "Humidity",

        startAngle: 40,
        ticksAngle: 280,
        colorPlate: "#ffffff",
        //colorPlateEnd: "#ffffff",
        colorUnits: "#3CA7DB",
        colorNumbers: "#534638",
        colorNeedle: "#8E7860",
        colorNeedleEnd: "#8E7860",
        colorNeedleCircleOuter: "#8E7860",
        colorNeedleCircleOuterEnd: "#8E7860",

        colorNeedleShadowUp: "#8E7860",
        colorNeedleShadowDown: "#8E7860",

        colorMajorTicks: ["#EBEBEB", "#EBEBEB", "#EBEBEB", "#EBEBEB", "#EBEBEB", "#EBEBEB"],
        colorMinorTicks: "#EBEBEB",

        minValue: 0,
        maxValue: 100,
        // maxValue: 200,
        majorTicks: ["0","20","40","60","80","100"],
        // majorTicks: ["0","20","40","60","80","100","120","140","160","180","200"],
        minorTicks: "2",
        strokeTicks: true,
        highlights: [
            {
                "from": -0.25,
                "to": 39.99,
                "color": "#30E3DF"
            },
            {
                "from": 39.99,
                "to": 65.99,
                "color": "#FCE22A"
            },
            {
                "from": 65.99,
                "to": 100.25,
                "color": "#F94A29"
            }
        ],
        //
        highlightsWidth: 25,
        numbersMargin: 12,
        //
        //barWidth: 20,
        //barStrokeWidth: 0,
        //barProgress: 1,
        //barShadow: 0,
        //
        animation: true,
        //animationDuration: 500,
        animationRule: "linear",
        animatedValue: true,
        //animateOnInit: true,

        borders: true,
        valueBox: true,

        needleType: "arrow",
        needleEnd: 65,
        needleWidth: 4,
        needleCircleSize: 10,
        needleCircleInner: true,
        needleCircleOuter: true,
        needleShadow: true,

        borderShadowWidth: 4
    }).draw();

    var gauge3 = new RadialGauge({
        // ... (your existing gauge configuration)
        renderTo: 'gauge-ldr',
        width: 300,
        height: 300,
        units: "Lux",
        title: "Ldr",

        startAngle: 40,
        ticksAngle: 280,
        colorPlate: "#ffffff",
        //colorPlateEnd: "#ffffff",
        colorUnits: "#3CA7DB",
        colorNumbers: "#534638",
        colorNeedle: "#8E7860",
        colorNeedleEnd: "#8E7860",
        colorNeedleCircleOuter: "#8E7860",
        colorNeedleCircleOuterEnd: "#8E7860",

        colorNeedleShadowUp: "#8E7860",
        colorNeedleShadowDown: "#8E7860",

        colorMajorTicks: ["#EBEBEB", "#EBEBEB", "#EBEBEB", "#EBEBEB", "#EBEBEB", "#EBEBEB"],
        colorMinorTicks: "#EBEBEB",

        minValue: 0,
        maxValue: 100,
        // maxValue: 200,
        majorTicks: ["0","20","40","60","80","100"],
        // majorTicks: ["0","20","40","60","80","100","120","140","160","180","200"],
        minorTicks: "2",
        strokeTicks: true,
        highlights: [
            {
                "from": -0.25,
                "to": 39.99,
                "color": "#30E3DF"
            },
            {
                "from": 39.99,
                "to": 65.99,
                "color": "#FCE22A"
            },
            {
                "from": 65.99,
                "to": 100.25,
                "color": "#F94A29"
            }
        ],
        //
        highlightsWidth: 25,
        numbersMargin: 12,
        //
        //barWidth: 20,
        //barStrokeWidth: 0,
        //barProgress: 1,
        //barShadow: 0,
        //
        animation: true,
        //animationDuration: 500,
        animationRule: "linear",
        animatedValue: true,
        //animateOnInit: true,

        borders: true,
        valueBox: true,

        needleType: "arrow",
        needleEnd: 65,
        needleWidth: 4,
        needleCircleSize: 10,
        needleCircleInner: true,
        needleCircleOuter: true,
        needleShadow: true,

        borderShadowWidth: 4
    }).draw();

// Fetch data initially and then at regular intervals
fetchData();
setInterval(fetchData, 500); // Update every 5 seconds (adjust as needed)