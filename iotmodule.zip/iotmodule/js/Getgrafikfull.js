function fetchData() {
    $.ajax({
        url: 'backend/aksigrafikfull.php', // Ganti dengan alamat URL yang sesuai
        method: 'GET',
        dataType: 'json',
        success: function (data) {
            // Menggabungkan ketiga dataset menjadi satu
            myChart.data.labels = data.labels;
            myChart.data.datasets[0].data = data.values1;
            myChart.data.datasets[1].data = data.values2;
            myChart.data.datasets[2].data = data.values3;
            myChart.update();
        },
        error: function (xhr, status, error) {
            console.error('Error fetching data:', error);
        }
    });
}

var ctx = document.getElementById("chart-sensor").getContext("2d");

var myChart = new Chart(ctx, {
    type: "line",
    data: {
        labels: [],
        datasets: [
            {
              label: "Sensor Temperature",
              tension: 0,
              borderWidth: 0,
              pointRadius: 5,
              pointBackgroundColor: "rgba(0, 0, 0, .8)",
              pointBorderColor: "transparent",
              borderColor: "rgba(0, 255, 255, .8)",
              borderWidth: 4,
              backgroundColor: "rgba(255, 255, 255, .8)",
                data: [],
                maxBarThickness: 6,
            },
            {
              label: "Sensor Humidity",
              tension: 0,
              borderWidth: 0,
              pointRadius: 5,
              pointBackgroundColor: "rgba(0, 0, 0, .8)",
              pointBorderColor: "transparent",
              borderColor: "rgba(255, 0, 0, .8)",
              borderWidth: 4,
              backgroundColor: "rgba(255, 255, 255, .8)",
                data: [],
                maxBarThickness: 6,
            },
            {
              label: "Sensor LDR",
              tension: 0,
              borderWidth: 0,
              pointRadius: 5,
              pointBackgroundColor: "rgba(0, 0, 0, .8)",
              pointBorderColor: "transparent",
              borderColor: "rgba(0, 0, 255, .8)",
              borderWidth: 4,
              backgroundColor: "rgba(255, 255, 255, .8)",
                data: [],
                maxBarThickness: 6,
            },
        ],
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: true,
            },
        },
        interaction: {
            intersect: false,
            mode: "index",
        },
        scales: {
            y: {
                grid: {
                    drawBorder: false,
                    display: true,
                    drawOnChartArea: true,
                    drawTicks: false,
                    borderDash: [5, 5],
                    color: "rgba(0, 0, 0, .2)",
                },
                ticks: {
                    suggestedMin: 0,
                    suggestedMax: 500,
                    beginAtZero: true,
                    padding: 10,
                    font: {
                        size: 14,
                        weight: 300,
                        family: "Roboto",
                        style: "normal",
                        lineHeight: 2,
                    },
                    color: "rgba(0, 0, 0, .8)",
                },
            },
            x: {
                grid: {
                    drawBorder: false,
                    display: true,
                    drawOnChartArea: true,
                    drawTicks: false,
                    borderDash: [5, 5],
                    color: "rgba(0, 0, 0, .2)",
                },
                ticks: {
                    display: true,
                    color: "rgba(0, 0, 0, .8)",
                    padding: 10,
                    font: {
                        size: 14,
                        weight: 300,
                        family: "Roboto",
                        style: "normal",
                        lineHeight: 2,
                    },
                },
            },
        },
    },
});

setInterval(fetchData, 500);