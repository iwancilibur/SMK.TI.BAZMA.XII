<?php
//require "koneksi.php"
 $connection = mysqli_connect("localhost", "root", "", "dbiot");

// if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $switchId  = $_POST["id"];
    $newStatus = $_POST["status"];
    
    $updateQuery1 = "UPDATE tb_control SET control$switchId = $newStatus"; //control(ID) 
    mysqli_query($connection, $updateQuery1);

    $updateQuery2 = "UPDATE tb_button SET status = $newStatus WHERE id = $switchId";
    mysqli_query($connection, $updateQuery2);
  
    echo json_encode(["message" => "Switch status updated successfully."]);
// }
?>
