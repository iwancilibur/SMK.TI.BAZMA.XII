<?php
require "koneksi.php";

//MENJADIKAN JSON DATA UNTUK BUTTON
$response = query("SELECT * FROM tb_button");
$result = json_encode($response);
echo $result;
?>