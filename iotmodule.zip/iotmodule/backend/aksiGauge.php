<?php
 include 'koneksi.php';
 $data = query("SELECT * FROM tb_save ORDER BY waktu DESC LIMIT 1")[0];
 $sensor1=$data["sensor1"];
 $sensor2=$data["sensor2"];
 $sensor3=$data["sensor3"];

 if($sensor1!=null){
    $data = [
        'values1' => $sensor1,
        'values2' => $sensor2,
        'values3' => $sensor3
    ];
 }else{
    $data = [
        'values1' => 0,
        'values2' => 0,
        'values3' => 0
    ];
 }
 

header('Content-Type: application/json');
echo json_encode($data);
?>
