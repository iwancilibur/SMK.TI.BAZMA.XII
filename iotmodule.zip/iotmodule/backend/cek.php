<?php

// Data asli
$data = array(
    "labels" => [
        "03:11:24",
        "03:11:05",
        "03:10:39",
        "03:42:47",
        "11:25:51"
    ],
    "values1" => [
        "35",
        "35",
        "1",
        "33",
        "34.00"
    ],
    "values2" => [
        "44",
        "44",
        "1",
        "45",
        "33.00"
    ],
    "values3" => [
        "55",
        "55",
        "1",
        "23",
        "31.00"
    ]
);

// Menggabungkan data labels dengan masing-masing nilai
$combinedData = array_map(function ($label, $value1, $value2, $value3) {
    return array("label" => $label, "values" => array("values1" => $value1, "values2" => $value2, "values3" => $value3));
}, $data["labels"], $data["values1"], $data["values2"], $data["values3"]);

// Mengurutkan data berdasarkan label secara descending
usort($combinedData, function ($a, $b) {
    return strtotime($b["label"]) - strtotime($a["label"]);
});

// Memisahkan kembali data menjadi labels, values1, values2, values3
$sortedData = array(
    "labels" => array_column($combinedData, "label"),
    "values1" => array_column(array_column($combinedData, "values"), "values1"),
    "values2" => array_column(array_column($combinedData, "values"), "values2"),
    "values3" => array_column(array_column($combinedData, "values"), "values3"),
);

// Menampilkan data yang sudah diurutkan
header('Content-Type: application/json');
echo json_encode($sortedData);
// print_r($sortedData);

?>
