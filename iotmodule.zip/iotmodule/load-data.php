<?php
  include 'backend/koneksi.php';
  $data = query("SELECT * FROM tb_monitoring")[0];
?> 

<!DOCTYPE html>
<html>
<head>
 <title></title>
</head>
<body >
		<table border=2 width=90% align="center">
        <tr >
		<td bgcolor=grey colspan="5" align="center"><font color=white size=20>DASHBOARD MONITORING</td>
		</tr>
		
		<tr bgcolor=yellow>
			<td><h5 >NAMA DEVICE</h5></td>
			<td><h5 >WAKTU</h5></td>
			<td><h5 >SENSOR 1</h5></td>
			<td><h5 >SENSOR 2</h5></td>
			<td><h5 >SENSOR 3</h5></td>
		</tr>
		<tr>
			<td><h5 class="mb-1"><?=$data["namadevice"];?></h5></td>
			<td><h5 class="mb-1"><?=$data["waktu"];?></h5></td>
			<td><h5 class="mb-1"><?=$data["sensor1"];?></h5></td>
			<td><h5 class="mb-1"><?=$data["sensor2"];?></h5></td>
			<td><h5 class="mb-1"><?=$data["sensor3"];?></h5></td>
		</tr>
		
		</table>


</body>
</html>


