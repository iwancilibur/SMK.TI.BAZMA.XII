<?php 

   //Simpan dengan nama file panel.php
     require "backend/koneksi.php";
 ?>
 
<!doctype html>
<html lang="en">
 
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>DASHBOARD IOT</title>
	
	<!-- CSS Files -->
	<link id="pagestyle" href="css/material-dashboard.css?v=3.1.0" rel="stylesheet" />
	<link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body align="center">
	<div align="center">
	 <img src="img/icon.png" height=100 width=200>
	</div>
	 <table border=2 width=90% align="center">
	 <!-- Realtime Load data -->
	 <!-- <div class="load-data"></div> -->
	 <!-- <canvas id="canvas-id"></canvas> -->
	 	
	 <tr align="center">
			<td>
				<h1 align="center">GAUGE</h1>
				<div class="row mt-4">
					<div class="col-lg-4 col-md-6 mt-4 mb-4">
						<div class="card z-index-2 ">
							<div class="card-body">
							<p class="text-sm ">GAUGE</p>
							<canvas id="gauge-temperature"></canvas>
							</div>
						</div>
					</div>

					<div class="col-lg-4 col-md-6 mt-4 mb-4">
						<div class="card z-index-2 ">
							<div class="card-body">
							<p class="text-sm ">GAUGE</p>
							<canvas id="gauge-humidity"></canvas>
							</div>
						</div>
					</div>

					<div class="col-lg-4 mt-4 mb-3">
						<div class="card z-index-2 ">
							<div class="card-body">
							<p class="text-sm ">GAUGE</p>
							<canvas id="gauge-ldr"></canvas>
							</div>
						</div>
					</div>
				</div>
			</td>
        </tr>

		<tr align="center">
			<td>
				<h1 align="center">GRAFIK</h1>
				<div class="row mt-4">
					<div class="col-lg-4 col-md-6 mt-4 mb-4">
						<div class="card z-index-2 ">
							<div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2 bg-transparent">
							<div class="bg-gradient-primary shadow-primary border-radius-lg py-3 pe-1">
								<div class="chart">
								<!-- GRAFIK 1 -->
								<canvas id="chart-sensor1" class="chart-canvas" height="170"></canvas>
								</div>
							</div>
							</div>
							<div class="card-body">
							<h6 class="mb-0 "> Grafik Temperature</h6>
							<p class="text-sm ">5 data realtime grafik</p>
							<hr class="dark horizontal">
							</div>
						</div>
					</div>

					<div class="col-lg-4 col-md-6 mt-4 mb-4">
						<div class="card z-index-2  ">
							<div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2 bg-transparent">
							<div class="bg-gradient-success shadow-success border-radius-lg py-3 pe-1">
								<div class="chart">
								<!-- GRAFIK 2 -->
								<canvas id="chart-sensor2" class="chart-canvas" height="170"></canvas>
								</div>
							</div>
							</div>
							<div class="card-body">
							<h6 class="mb-0 "> Grafik Humidity </h6>
							<p class="text-sm "> 5 data realtime grafik. </p>
							<hr class="dark horizontal">
							
							</div>
						</div>
					</div>

					<div class="col-lg-4 mt-4 mb-3">
						<div class="card z-index-2 ">
							<div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2 bg-transparent">
							<div class="bg-gradient-dark shadow-dark border-radius-lg py-3 pe-1">
								<div class="chart">
								<!-- GRAFIK 3 -->
								<canvas id="chart-sensor3" class="chart-canvas" height="170"></canvas>
								</div>
							</div>
							</div>
							<div class="card-body">
							<h6 class="mb-0 "> Grafik LDR</h6>
							<p class="text-sm ">5 data realtime grafik.</p>
							<hr class="dark horizontal">
							
							</div>
						</div>
					</div>
				</div>
				
				<div class="row mb-4">
					<div class="col-lg-8 col-md-6 mb-md-0 mb-4">
					<div class="card">
						<div class="card-header pb-0">
						<div class="row">
							<div class="col-lg-6 col-7">
							<h6>Realtime Data </h6>
							<p class="text-sm mb-0">
								<i class="fa fa-check text-info" aria-hidden="true"></i>
								<span class="font-weight-bold ms-1">10 done</span> Data Realtime
							</p>
							</div>
							<div class="col-lg-6 col-5 my-auto text-end">
							<div class="dropdown float-lg-end pe-4">
								<a class="cursor-pointer" id="dropdownTable" data-bs-toggle="dropdown" aria-expanded="false">
								<i class="fa fa-ellipsis-v text-secondary"></i>
								</a>
								<ul class="dropdown-menu px-2 py-3 ms-sm-n4 ms-n5" aria-labelledby="dropdownTable">
								<li><a class="dropdown-item border-radius-md" href="javascript:;">Action</a></li>
								<li><a class="dropdown-item border-radius-md" href="javascript:;">Another action</a></li>
								<li><a class="dropdown-item border-radius-md" href="javascript:;">Something else here</a></li>
								</ul>
							</div>
							</div>
						</div>
						</div>
						<div class="card-body px-0 pb-2">
						<!-- GRAFIK REALTIME 10 DATA -->
						<canvas id="chart-sensor" class="chart-canvas" height="370"></canvas>
						</div>
					</div>
					</div>
					<div class="col-lg-4 col-md-6">
					<div class="card h-100">
						<div class="card-header pb-0">
						<h6>Menu Kontrol</h6>
						<p class="text-sm">
							<i class="fa fa-arrow-up text-success" aria-hidden="true"></i>
							<span class="font-weight-bold">24</span> Hourse Realtime
						</p>
						</div>
						<div class="card-body p-3" align="center">
						<!-- UNTUK TOMBOL KENDALI -->
						<div id="switches"></div>
						
						</div>
						<a href="backend/data-hapus.php" class="btn btn-default btn-danger" height="50" width="50">Hapus Semua Data</a>
						<a href="data-tampil.php" class="btn btn-default btn-success" height="50" width="50">Lihat Semua data</a>
					</div>
					</div>
				</div>
			</td>
        </tr>
      </table>

	
 <p align="center"> Copyright © 2021 Iwan Cilibur. All rights reserved. </p>
 <!-- JAVA SCRIPT BASIC -->
 <script src="js/jquery-3.6.0.min.js"></script>
 <script src="js/chart.js"></script>
 <script src="js/gauge.min.js"></script>

 <!-- JAVA SCRIPT ACTION -->
 <script src="js/GetReloaddata.js"></script>
 <script src="js/Getcontrolbutton.js"> </script>
 <script src="js/Getgrafik.js"></script>
 <script src="js/Getgrafikfull.js"></script>
 <script src="js/GetGauge.js"></script>



</body>
 
</html>
