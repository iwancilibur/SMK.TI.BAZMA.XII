-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 18, 2023 at 05:22 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbiot`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_button`
--

CREATE TABLE `tb_button` (
  `id` int(10) NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_button`
--

INSERT INTO `tb_button` (`id`, `keterangan`, `status`) VALUES
(1, 'LAMPU 1', '1'),
(2, 'LAMPU 2', '1'),
(3, 'KIPAS 1', '1'),
(4, 'GERBANG', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tb_control`
--

CREATE TABLE `tb_control` (
  `control1` varchar(100) NOT NULL,
  `control2` varchar(100) NOT NULL,
  `control3` int(100) NOT NULL,
  `control4` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_control`
--

INSERT INTO `tb_control` (`control1`, `control2`, `control3`, `control4`) VALUES
('1', '1', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_monitoring`
--

CREATE TABLE `tb_monitoring` (
  `waktu` datetime NOT NULL,
  `namadevice` varchar(100) NOT NULL,
  `sensor1` varchar(100) NOT NULL,
  `sensor2` varchar(100) NOT NULL,
  `sensor3` varchar(100) NOT NULL,
  `sensor4` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_monitoring`
--

INSERT INTO `tb_monitoring` (`waktu`, `namadevice`, `sensor1`, `sensor2`, `sensor3`, `sensor4`) VALUES
('2023-10-16 04:03:15', 'iwan', '30', '32', '33', '55');

-- --------------------------------------------------------

--
-- Table structure for table `tb_save`
--

CREATE TABLE `tb_save` (
  `id` int(11) NOT NULL,
  `waktu` datetime NOT NULL,
  `namadevice` varchar(100) NOT NULL,
  `sensor1` varchar(100) NOT NULL,
  `sensor2` varchar(100) NOT NULL,
  `sensor3` varchar(100) NOT NULL,
  `sensor4` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_save`
--

INSERT INTO `tb_save` (`id`, `waktu`, `namadevice`, `sensor1`, `sensor2`, `sensor3`, `sensor4`) VALUES
(17062, '2023-10-16 03:56:28', 'iwan', '30', '10', '20', ''),
(17063, '2023-10-16 03:57:01', 'iwan', '33', '30', '23', ''),
(17064, '2023-10-16 03:57:21', 'iwan', '33', '20', '33', ''),
(17065, '2023-10-16 03:57:31', 'iwan', '53', '55', '35', ''),
(17066, '2023-10-16 03:57:40', 'iwan', '54', '45', '45', ''),
(17067, '2023-10-16 04:02:15', 'iwan', '24', '35', '47', ''),
(17068, '2023-10-16 04:02:45', 'iwan', '24', '35', '47', ''),
(17069, '2023-10-16 04:02:48', 'iwan', '24', '35', '47', ''),
(17070, '2023-10-16 04:02:50', 'iwan', '24', '35', '47', ''),
(17071, '2023-10-16 04:03:02', 'iwan', '1', '2', '3', ''),
(17072, '2023-10-16 04:03:15', 'iwan', '30', '32', '33', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_button`
--
ALTER TABLE `tb_button`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_save`
--
ALTER TABLE `tb_save`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_button`
--
ALTER TABLE `tb_button`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tb_save`
--
ALTER TABLE `tb_save`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17073;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
